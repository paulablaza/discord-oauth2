# dicord_oauth2

A python library that uses discord's api for easy authentication for your website.

## Installation

Install discord-oauth2 with npm

```bash
  pip3 install discord-oauth2
```

## Documentation

(soon)

## FAQ

#### Simpler documentation?

(soon)

## Author

- [@paulablaza](https://www.github.com/paulablaza)

## License

[MIT](https://choosealicense.com/licenses/mit/)
